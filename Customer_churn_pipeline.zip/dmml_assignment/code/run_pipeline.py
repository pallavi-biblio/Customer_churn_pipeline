import logging

# Configure logging
log_file = r"execution.log"
logging.basicConfig(filename=log_file, level=logging.INFO, format='%(asctime)s - %(message)s')

def log(message):
    logging.info(message)
    print(message)


import subprocess

scripts = ["data_ingestion.py", "data_validation.py", "data_preparation.py", "populate_feature_store.py", "data_preprocessing.py", "modeltraining.py"]

for script in scripts:
    print(f"Running {script}...")
    logging.info(f"Running {script}...")
    subprocess.run(["python", script])  # Runs each script