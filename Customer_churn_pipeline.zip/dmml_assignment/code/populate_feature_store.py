import sqlite3
import pandas as pd

# Load processed data
processed_data_path = "C:/Users/palla/Desktop/customer_churn_pipeline/processed_data/customers_cleaned_20250314.csv"
df = pd.read_csv(processed_data_path)

# Verify required columns
required_columns = ["customerID", "TotalCharges", "tenure", "transaction_frequency"]
missing_columns = [col for col in required_columns if col not in df.columns]

if missing_columns:
    print(f"❌ ERROR: Missing columns in processed data: {missing_columns}")
    exit()

# Connect to Feature Store
db_path = "C:/Users/palla/Desktop/customer_churn_pipeline/feature_store.db"
conn = sqlite3.connect(db_path)

# Insert transformed data into customer_features table
df.to_sql("customer_features", conn, if_exists="replace", index=False)

# Verify insertion
df_check = pd.read_sql("SELECT COUNT(*) FROM customer_features", conn)
print(f"✅ Successfully inserted {df_check.iloc[0, 0]} records into customer_features!")

conn.close()
