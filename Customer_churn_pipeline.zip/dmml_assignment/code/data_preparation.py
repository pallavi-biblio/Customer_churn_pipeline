import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler, LabelEncoder
from datetime import datetime

# Define paths
RAW_DATA_DIR = r"C:/Users/palla/Desktop/customer_churn_pipeline/raw_data/csv/"
PROCESSED_DATA_DIR = r"C:/Users/palla/Desktop/customer_churn_pipeline/processed_data/"
os.makedirs(PROCESSED_DATA_DIR, exist_ok=True)

# Load latest raw data file
csv_files = sorted([f for f in os.listdir(RAW_DATA_DIR) if f.startswith("customers_")])
if csv_files:
    latest_csv = os.path.join(RAW_DATA_DIR, csv_files[-1])
    df = pd.read_csv(latest_csv)
    print(f"Loaded data from {latest_csv}")
else:
    print("No raw data found.")
    exit()

# Handle missing values
def handle_missing_values(df):
    for col in df.columns:
        if df[col].isnull().sum() > 0:
            if df[col].dtype == 'object':  # Categorical
                df[col].fillna(df[col].mode()[0], inplace=True)
            else:  # Numerical
                df[col].fillna(df[col].median(), inplace=True)
    return df

df = handle_missing_values(df)

# Standardize numerical features
num_cols = df.select_dtypes(include=['int64', 'float64']).columns
scaler = StandardScaler()
df[num_cols] = scaler.fit_transform(df[num_cols])

# Encode categorical features using Label Encoding
cat_cols = df.select_dtypes(include=['object']).columns
for col in cat_cols:
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col])

# Save cleaned data
timestamp = datetime.now().strftime("%Y%m%d")
processed_file = os.path.join(PROCESSED_DATA_DIR, f"customers_cleaned_{timestamp}.csv")
df.to_csv(processed_file, index=False)
print(f"Cleaned data saved at: {processed_file}")

# Perform EDA
plt.figure(figsize=(10,6))
sns.histplot(df, kde=True)
plt.title("Distribution of Processed Data")
plt.savefig(os.path.join(PROCESSED_DATA_DIR, "data_distribution.png"))
plt.show()
