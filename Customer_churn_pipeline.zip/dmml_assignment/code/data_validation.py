import pandas as pd
import os


# Define paths
DATA_PATH = "C:/Users/palla/Desktop/customer_churn_pipeline/raw_data/csv/raw/"
VALIDATION_REPORT_PATH = "C:/Users/palla/Desktop/customer_churn_pipeline/data_validation/"
os.makedirs(VALIDATION_REPORT_PATH, exist_ok=True)

# Function to load the latest CSV file
def get_latest_csv():
    subfolders = sorted(os.listdir(DATA_PATH), reverse=True)  # Sort folders by date
    if not subfolders:
        print("❌ No data found in raw_data/csv/raw/")
        return None
    latest_folder = os.path.join(DATA_PATH, subfolders[0])
    files = [f for f in os.listdir(latest_folder) if f.endswith(".csv")]
    if not files:
        print("❌ No CSV file found in the latest folder.")
        return None
    latest_file = os.path.join(latest_folder, files[0])
    print(f"📂 Using latest file: {latest_file}")
    return latest_file

# Function to safely get a column
def safe_get_column(df, column_name):
    column_name = column_name.strip()
    df.columns = df.columns.str.strip()
    if column_name in df.columns:
        return df[column_name]
    else:
        print(f"⚠️ Warning: Column '{column_name}' not found in the CSV!")
        return None

# Function to perform data validation
def validate_data(file_path):
    df = pd.read_csv(file_path)

    # Convert numeric columns to proper data types
    numeric_columns = ["tenure", "MonthlyCharges", "TotalCharges"]
    for col in numeric_columns:
        df[col] = pd.to_numeric(df[col], errors='coerce')  # Convert, set errors to NaN

    report = {}

    # 1️⃣ Check for missing values
    missing_values = df.isnull().sum()
    report["Missing Values"] = missing_values[missing_values > 0].to_dict()

    # 2️⃣ Validate Data Types
    expected_types = {
        "customerID": "object", "gender": "object", "SeniorCitizen": "int64", "Partner": "object",
        "Dependents": "object", "tenure": "int64", "PhoneService": "object", "MultipleLines": "object",
        "InternetService": "object", "OnlineSecurity": "object", "OnlineBackup": "object", "DeviceProtection": "object",
        "TechSupport": "object", "StreamingTV": "object", "StreamingMovies": "object", "Contract": "object",
        "PaperlessBilling": "object", "PaymentMethod": "object", "MonthlyCharges": "float64", "TotalCharges": "float64",
        "Churn": "object"
    }
    type_issues = {col: str(df[col].dtype) for col in df.columns if col in expected_types and df[col].dtype != expected_types[col]}
    report["Incorrect Data Types"] = type_issues

    # 3️⃣ Validate Ranges
    tenure_column = safe_get_column(df, "tenure")
    tenure_issues = tenure_column[tenure_column < 0].tolist() if tenure_column is not None else []

    monthly_charges_column = safe_get_column(df, "MonthlyCharges")
    monthly_charges_issues = monthly_charges_column[monthly_charges_column < 0].tolist() if monthly_charges_column is not None else []

    total_charges_column = safe_get_column(df, "TotalCharges")
    total_charges_issues = total_charges_column[total_charges_column < 0].tolist() if total_charges_column is not None else []

    report["Negative Tenure Values"] = str(tenure_issues)
    report["Negative Monthly Charges"] = str(monthly_charges_issues)
    report["Negative Total Charges"] = str(total_charges_issues)

    # 4️⃣ Check for Duplicates
    duplicate_count = df.duplicated().sum()
    report["Duplicate Rows"] = str(duplicate_count)

    # 5️⃣ Identify Anomalies (Outliers using IQR method)
    if monthly_charges_column is not None:
        Q1 = monthly_charges_column.quantile(0.25)
        Q3 = monthly_charges_column.quantile(0.75)
        IQR = Q3 - Q1
        outliers = monthly_charges_column[(monthly_charges_column < (Q1 - 1.5 * IQR)) | (monthly_charges_column > (Q3 + 1.5 * IQR))].tolist()
    else:
        outliers = []

    report["Outliers in Monthly Charges"] = str(outliers)

    # Convert report to DataFrame & save to CSV
    report_df = pd.DataFrame(list(report.items()), columns=["Issue Type", "Details"])
    report_path = os.path.join(VALIDATION_REPORT_PATH, "data_quality_report.csv")
    report_df.to_csv(report_path, index=False)

    print(f"✅ Data validation completed. Report saved at: {report_path}")

# Run Data Validation
latest_csv = get_latest_csv()
if latest_csv:
    validate_data(latest_csv)
