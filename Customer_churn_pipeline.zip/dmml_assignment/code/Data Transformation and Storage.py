
import pandas as pd
import numpy as np

# Load processed data
processed_data_path = "C:/Users/palla/Desktop/customer_churn_pipeline/processed_data/customers_cleaned_20250314.csv"
df = pd.read_csv(processed_data_path)

# Generate transaction frequency (handling missing or zero values)
df["transaction_frequency"] = df["TotalCharges"] / (df["tenure"] + 1)

# Handle any NaN values
df["transaction_frequency"].fillna(df["transaction_frequency"].median(), inplace=True)

# Save updated processed data
df.to_csv(processed_data_path, index=False)

print("✅ Added 'transaction_frequency' to processed data.")
