import sqlite3
import os
import pandas as pd
import requests
import json
from datetime import datetime


# Define base directory in Google Drive
BASE_DIR = "C:/Users/palla/Desktop/customer_churn_pipeline/raw_data/"
os.makedirs(BASE_DIR, exist_ok=True)

# Function to create folder structure based on date
def get_storage_path(source_type):
    today = datetime.today().strftime('%Y-%m-%d')
    path = os.path.join(BASE_DIR, source_type, "raw", today)
    os.makedirs(path, exist_ok=True)
    return path

# Function to ingest CSV data
def ingest_csv(csv_path):
    try:
        data = pd.read_csv(csv_path)
        storage_path = get_storage_path("csv")
        file_name = f"customers_raw_{datetime.today().strftime('%Y%m%d')}.csv"
        data.to_csv(os.path.join(storage_path, file_name), index=False)
        print(f"CSV data saved to {storage_path}/{file_name}")
        return data
    except Exception as e:
        print(f"Error reading CSV: {e}")
        return None

# Function to fetch and store API data
def fetch_api_data(api_url):
    try:
        response = requests.get(api_url)
        response.raise_for_status()
        data = response.json()
        storage_path = get_storage_path("api")
        file_name = f"api_raw_{datetime.today().strftime('%Y%m%d')}.json"
        with open(os.path.join(storage_path, file_name), 'w') as f:
            json.dump(data, f, indent=4)
        print(f"API data saved to {storage_path}/{file_name}")
        return data
    except requests.RequestException as e:
        print(f"API request failed: {e}")
        return None

# Example usage
csv_file_path = "C:/Users/palla/Desktop/customer_churn_pipeline/customers.csv"  # Ensure the file is uploaded
api_url = "https://jsonplaceholder.typicode.com/users"  # Simulated API

csv_data = ingest_csv(csv_file_path)
api_data = fetch_api_data(api_url)

print("Data Ingestion Complete!")


CREATE TABLE customers (
    customer_id INTEGER PRIMARY KEY,
    total_spend_per_month REAL,
    customer_tenure INTEGER,
    transaction_frequency REAL,
    age INTEGER,
    income REAL,
    gender TEXT,
    location TEXT
);
