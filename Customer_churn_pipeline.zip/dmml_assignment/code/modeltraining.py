import os
import sqlite3
import mlflow
import mlflow.sklearn
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
import joblib

# Define database path
FEATURE_STORE_DB = "C:/Users/palla/Desktop/customer_churn_pipeline/feature_store.db"
MODEL_PATH = "C:/Users/palla/Desktop/customer_churn_pipeline/models/"
os.makedirs(MODEL_PATH, exist_ok=True)

# Load data from SQLite feature store
conn = sqlite3.connect(FEATURE_STORE_DB)
df = pd.read_sql("SELECT * FROM customer_features", conn)
conn.close()

# Split data into features (X) and target (y)
X = df.drop(columns=['customerID'])  # Exclude customer_id
y = (df['transaction_frequency'] < 0.5).astype(int)  # Example churn definition

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Standardize numerical features
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Train models
models = {
    "Logistic Regression": LogisticRegression(),
    "Random Forest": RandomForestClassifier(n_estimators=100, random_state=42)
}

results = {}

mlflow.set_experiment("customer_churn_prediction")

for name, model in models.items():
    with mlflow.start_run():
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        
        # Evaluate model
        acc = accuracy_score(y_test, y_pred)
        prec = precision_score(y_test, y_pred)
        rec = recall_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred)
        
        results[name] = {"Accuracy": acc, "Precision": prec, "Recall": rec, "F1 Score": f1}
        
        # Log metrics
        mlflow.log_param("Model", name)
        mlflow.log_metric("Accuracy", acc)
        mlflow.log_metric("Precision", prec)
        mlflow.log_metric("Recall", rec)
        mlflow.log_metric("F1 Score", f1)
        
        # Save model
        model_filename = os.path.join(MODEL_PATH, f"{name.replace(' ', '_').lower()}.pkl")
        joblib.dump(model, model_filename)
        mlflow.sklearn.log_model(model, name)
        print(f"Model {name} saved at {model_filename}")

# Print evaluation results
print("\nModel Performance:")
pd.DataFrame(results).T.to_csv(os.path.join(MODEL_PATH, "model_performance.csv"))
print(pd.DataFrame(results).T)

# Plot confusion matrix for the best model
best_model = max(results, key=lambda k: results[k]['F1 Score'])
final_model = joblib.load(os.path.join(MODEL_PATH, f"{best_model.replace(' ', '_').lower()}.pkl"))
y_pred_final = final_model.predict(X_test)
cm = confusion_matrix(y_test, y_pred_final)
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
plt.title(f"Confusion Matrix - {best_model}")
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.savefig(os.path.join(MODEL_PATH, "confusion_matrix.png"))
plt.show()

