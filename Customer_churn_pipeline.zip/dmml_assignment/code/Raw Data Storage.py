import os
import pandas as pd
from datetime import datetime

# Define base directory for raw data storage
data_dir = r"C:/Users/palla/Desktop/customer_churn_pipeline/raw_data/"
os.makedirs(data_dir, exist_ok=True)

# Create subdirectories for CSV and API data
csv_dir = os.path.join(data_dir, "csv")
api_dir = os.path.join(data_dir, "api")
os.makedirs(csv_dir, exist_ok=True)
os.makedirs(api_dir, exist_ok=True)

# Function to store data with timestamp
def store_data(df, source_type, file_name):
    try:
        timestamp = datetime.now().strftime("%Y%m%d")
        file_path = os.path.join(source_type, f"{file_name}_{timestamp}.csv")
        df.to_csv(file_path, index=False)
        print(f"Data stored successfully: {file_path}")
    except Exception as e:
        print(f"Error storing data: {e}")

# Example usage
if __name__ == "__main__":
    # Load ingested data (assuming ingestion was successful)
    customers_df = pd.read_csv("raw_data/customers_raw.csv")
    api_df = pd.read_csv("raw_data/api_data_raw.csv")
    
    # Store data with timestamp
    store_data(customers_df, csv_dir, "customers")
    store_data(api_df, api_dir, "api_data")
    
    print("Raw data storage completed.")

